﻿namespace System.Configuration
{
    internal class ConfigurationManager
    {
        internal static object GetInstance()
        {
            throw new NotImplementedException();
        }
    }
}